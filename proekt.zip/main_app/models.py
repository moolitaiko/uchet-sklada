from django.db import models


class Products(models.Model):
    article = models.CharField(max_length=50)
    name = models.CharField(max_length=255, null=False, blank=False)
    category = models.ForeignKey('Category', on_delete = models.SET_NULL, null=False, blank=False)
    # purchase_price = models.PositiveIntegerField() создать отдельную таблицу для закупа
    sale_price = models.PositiveIntegerField()
    quantity = models.PositiveIntegerField()
    # expected_profit = нужно сделать формулу (sale_price - purchase_price) * quantity
    status = models.CharField(max_length=50, choices=[
        ('Новое', 'Новое'),
        ('БУ', 'Бывшее в Употреблении'),
        ('В наличии', 'В наличии'),
        ('Требует Ремонта', 'Требует Ремонта'),
        ('Требует Ревизии', 'Требует Ревизии'),
        ('НЕТ в наличии', 'Нет в наличии'),
    ])
    comments = models.TextField(null=True, blank=True)
    # распечатывать накладную

    def __str__(self):
        return str(self.name) + ' ' + str(self.article)


class Category(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name


class Customers(models.Model):
    name = models.CharField(max_length=255)
    telephone = models.CharField(max_length=255)
    bin = models.CharField(max_length=16, null=True, blank=True)


    def __str__(self):
        return str(self.name) + ' ' + str(self.telephone)

class
